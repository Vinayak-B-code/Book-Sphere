/* =========================
   BOOKSPHERE JAVASCRIPT
   ========================= */

const books = [
    {
        id: 1,
        title: "Java Programming",
        author: "Herbert Schildt",
        category: "Programming",
        price: 450,
        rating: 4.8,
        trending: true,
        availability: "Available",
        isbn: "9781260440218",
        image: "https://covers.openlibrary.org/b/isbn/9781260440218-L.jpg",
        description: "A practical introduction to Java programming, object-oriented concepts and application development."
    },
    {
        id: 2,
        title: "Python Crash Course",
        author: "Eric Matthes",
        category: "Programming",
        price: 520,
        rating: 4.7,
        trending: true,
        availability: "Available",
        isbn: "9781718502703",
        image: "https://covers.openlibrary.org/b/isbn/9781718502703-L.jpg",
        description: "A hands-on guide to Python fundamentals, projects and practical programming."
    },
    {
        id: 3,
        title: "Database System Concepts",
        author: "Abraham Silberschatz",
        category: "Database",
        price: 680,
        rating: 4.6,
        trending: false,
        availability: "Available",
        isbn: "9780078022159",
        image: "https://covers.openlibrary.org/b/isbn/9780078022159-L.jpg",
        description: "Learn database architecture, SQL, transactions, indexing and database design."
    },
    {
        id: 4,
        title: "HTML and CSS",
        author: "Jon Duckett",
        category: "Web Development",
        price: 590,
        rating: 4.7,
        trending: true,
        availability: "Available",
        isbn: "9781118008188",
        image: "https://covers.openlibrary.org/b/isbn/9781118008188-L.jpg",
        description: "A visual guide to building attractive and responsive websites using HTML and CSS."
    },
    {
        id: 5,
        title: "Artificial Intelligence",
        author: "Stuart Russell",
        category: "Artificial Intelligence",
        price: 750,
        rating: 4.8,
        trending: true,
        availability: "Not Available",
        isbn: "9780134610993",
        image: "https://covers.openlibrary.org/b/isbn/9780134610993-L.jpg",
        description: "An introduction to the foundations, methods and applications of artificial intelligence."
    },
    {
        id: 6,
        title: "The Alchemist",
        author: "Paulo Coelho",
        category: "Fiction",
        price: 299,
        rating: 4.5,
        trending: false,
        availability: "Available",
        isbn: "9780062315007",
        image: "https://covers.openlibrary.org/b/isbn/9780062315007-L.jpg",
        description: "A famous fictional story about dreams, discovery, personal goals and following one's journey."
    }
];

let favorites = JSON.parse(localStorage.getItem("booksphereFavorites")) || [];
let darkMode = localStorage.getItem("booksphereDarkMode") === "true";

const bookContainer = document.getElementById("bookContainer");
const trendingContainer = document.getElementById("trendingContainer");
const favoritesContainer = document.getElementById("favoritesContainer");
const recommendationContainer = document.getElementById("recommendationContainer");
const noResults = document.getElementById("noResults");
const emptyFavorites = document.getElementById("emptyFavorites");
const resultCount = document.getElementById("resultCount");
const favoriteCount = document.querySelector(".favorite-count");
const favoriteStat = document.getElementById("favoriteStat");
const bookStat = document.getElementById("bookStat");

function getStars(rating) {
    const full = Math.round(rating);
    return "★".repeat(full) + "☆".repeat(5 - full);
}

function statusBadge(status) {
    if (status === "Available") {
        return '<span class="badge text-bg-success status-badge">Available</span>';
    }
    return '<span class="badge text-bg-danger status-badge">Not Available</span>';
}

function isFavorite(id) {
    return favorites.includes(id);
}

function bookCard(book) {
    const favorite = isFavorite(book.id);

    return `
        <div class="col-md-6 col-xl-4">
            <div class="book-card">
                <div class="position-relative">
                    <img src="${book.image}" class="book-cover"
                         alt="${book.title}"
                         onerror="this.src='https://placehold.co/600x800?text=Book+Cover'">

                    <button class="favorite-btn position-absolute top-0 end-0 m-3 ${favorite ? "active" : ""}"
                            onclick="toggleFavorite(${book.id})"
                            title="Add to favorites">
                        <i class="bi ${favorite ? "bi-heart-fill" : "bi-heart"}"></i>
                    </button>

                    <span class="badge bg-primary position-absolute bottom-0 start-0 m-3">
                        ${book.category}
                    </span>
                </div>

                <div class="book-card-body">
                    <div class="d-flex justify-content-between align-items-start gap-2">
                        <div>
                            <h5 class="book-title mb-1">${book.title}</h5>
                            <p class="book-author mb-2">by ${book.author}</p>
                        </div>
                        ${statusBadge(book.availability)}
                    </div>

                    <div class="rating mb-2">
                        ${getStars(book.rating)}
                        <span class="text-muted ms-1">${book.rating}</span>
                    </div>

                    <p class="book-description">
                        ${book.description}
                    </p>

                    <div class="d-flex justify-content-between align-items-center">
                        <span class="price">₹${book.price}</span>
                        <button class="btn btn-primary btn-sm"
                                onclick="showBookDetails(${book.id})">
                            View Details
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderBooks(list = books) {
    bookContainer.innerHTML = list.map(bookCard).join("");
    resultCount.textContent = `${list.length} book${list.length !== 1 ? "s" : ""} found`;

    if (list.length === 0) {
        noResults.classList.remove("d-none");
    } else {
        noResults.classList.add("d-none");
    }
}

function renderTrending() {
    const trending = books.filter(book => book.trending);
    trendingContainer.innerHTML = trending.map(book => `
        <div class="col-md-6 col-lg-3">
            <div class="book-card">
                <div class="position-relative">
                    <img src="${book.image}" class="book-cover"
                         alt="${book.title}"
                         onerror="this.src='https://placehold.co/600x800?text=Book+Cover'">
                    <span class="badge bg-danger position-absolute top-0 start-0 m-3">
                        🔥 Trending
                    </span>
                </div>
                <div class="book-card-body">
                    <h5 class="book-title">${book.title}</h5>
                    <p class="book-author">${book.author}</p>
                    <div class="rating mb-3">${getStars(book.rating)} ${book.rating}</div>
                    <button class="btn btn-outline-primary btn-sm"
                            onclick="showBookDetails(${book.id})">
                        Explore
                    </button>
                </div>
            </div>
        </div>
    `).join("");
}

function renderFavorites() {
    const favoriteBooks = books.filter(book => favorites.includes(book.id));

    if (favoriteBooks.length === 0) {
        favoritesContainer.innerHTML = "";
        emptyFavorites.classList.remove("d-none");
    } else {
        emptyFavorites.classList.add("d-none");
        favoritesContainer.innerHTML = favoriteBooks.map(bookCard).join("");
    }

    updateFavoriteCount();
}

function renderRecommendations() {
    // Simple rule-based recommendation, not an AI model.
    const recommended = books
        .filter(book => book.rating >= 4.7)
        .slice(0, 3);

    recommendationContainer.innerHTML = recommended.map(book => `
        <div class="col-md-6 col-lg-4">
            <div class="book-card">
                <div class="book-card-body">
                    <span class="badge bg-info text-dark mb-2">Recommended</span>
                    <h5 class="book-title">${book.title}</h5>
                    <p class="book-author">${book.category} • ${book.author}</p>
                    <div class="rating mb-3">${getStars(book.rating)} ${book.rating}</div>
                    <button class="btn btn-primary btn-sm"
                            onclick="showBookDetails(${book.id})">
                        View Book
                    </button>
                </div>
            </div>
        </div>
    `).join("");
}

function updateFavoriteCount() {
    favoriteCount.textContent = favorites.length;
    favoriteStat.textContent = favorites.length;
}

function toggleFavorite(id) {
    if (favorites.includes(id)) {
        favorites = favorites.filter(item => item !== id);
        showToast("Favorite Removed", "Book removed from your favorites.");
    } else {
        favorites.push(id);
        showToast("Added to Favorites", "Book saved to your personal library.");
    }

    localStorage.setItem("booksphereFavorites", JSON.stringify(favorites));
    renderBooks(getFilteredBooks());
    renderFavorites();
}

function getFilteredBooks() {
    const searchTerm = document.getElementById("bookSearch").value.toLowerCase().trim();
    const category = document.getElementById("categoryFilter").value;
    const sort = document.getElementById("sortFilter").value;

    let filtered = books.filter(book => {
        const matchesSearch =
            book.title.toLowerCase().includes(searchTerm) ||
            book.author.toLowerCase().includes(searchTerm) ||
            book.category.toLowerCase().includes(searchTerm);

        const matchesCategory =
            category === "All" || book.category === category;

        return matchesSearch && matchesCategory;
    });

    if (sort === "rating") {
        filtered.sort((a, b) => b.rating - a.rating);
    } else if (sort === "priceLow") {
        filtered.sort((a, b) => a.price - b.price);
    } else if (sort === "priceHigh") {
        filtered.sort((a, b) => b.price - a.price);
    }

    return filtered;
}

function applyFilters() {
    renderBooks(getFilteredBooks());
}

function showBookDetails(id) {
    const book = books.find(item => item.id === id);
    if (!book) return;

    document.getElementById("modalTitle").textContent = book.title;

    document.getElementById("modalBody").innerHTML = `
        <div class="row g-4 align-items-center">
            <div class="col-md-5">
                <img src="${book.image}" class="modal-book-image"
                     alt="${book.title}"
                     onerror="this.src='https://placehold.co/600x800?text=Book+Cover'">
            </div>
            <div class="col-md-7">
                <span class="badge bg-primary mb-2">${book.category}</span>
                <h3>${book.title}</h3>
                <p class="text-muted">by ${book.author}</p>

                <div class="rating mb-3">
                    ${getStars(book.rating)} ${book.rating}/5
                </div>

                <p>${book.description}</p>

                <div class="mb-2"><strong>ISBN:</strong> ${book.isbn}</div>
                <div class="mb-2"><strong>Price:</strong> ₹${book.price}</div>
                <div class="mb-3"><strong>Status:</strong> ${statusBadge(book.availability)}</div>

                <button class="btn ${isFavorite(book.id) ? "btn-danger" : "btn-primary"}"
                        onclick="toggleFavorite(${book.id}); showBookDetails(${book.id});">
                    <i class="bi ${isFavorite(book.id) ? "bi-heart-fill" : "bi-heart"}"></i>
                    ${isFavorite(book.id) ? "Remove Favorite" : "Add to Favorites"}
                </button>
            </div>
        </div>
    `;

    const modal = new bootstrap.Modal(document.getElementById("bookModal"));
    modal.show();
}

function showToast(title, message) {
    document.getElementById("toastTitle").textContent = title;
    document.getElementById("toastMessage").textContent = message;

    const toast = bootstrap.Toast.getOrCreateInstance(
        document.getElementById("appToast")
    );

    toast.show();
}

function setCategory(category) {
    document.getElementById("categoryFilter").value = category;
    document.getElementById("bookSearch").value = "";
    applyFilters();

    document.getElementById("books").scrollIntoView({ behavior: "smooth" });
}

function surpriseMe() {
    const randomBook = books[Math.floor(Math.random() * books.length)];
    showToast("🎲 Surprise Book", `We picked "${randomBook.title}" for you!`);
    setTimeout(() => showBookDetails(randomBook.id), 350);
}

function updateThemeIcon() {
    const icon = document.querySelector("#themeToggle i");

    if (darkMode) {
        document.body.classList.add("dark-mode");
        icon.className = "bi bi-sun-fill";
    } else {
        document.body.classList.remove("dark-mode");
        icon.className = "bi bi-moon-stars-fill";
    }
}

function toggleTheme() {
    darkMode = !darkMode;
    localStorage.setItem("booksphereDarkMode", darkMode);
    updateThemeIcon();

    showToast(
        darkMode ? "Dark Mode" : "Light Mode",
        darkMode ? "Dark theme enabled." : "Light theme enabled."
    );
}

/* Search */
document.getElementById("searchInput").addEventListener("input", function () {
    document.getElementById("bookSearch").value = this.value;
    applyFilters();
});

document.getElementById("bookSearch").addEventListener("input", function () {
    document.getElementById("searchInput").value = this.value;
    applyFilters();
});

document.getElementById("categoryFilter").addEventListener("change", applyFilters);
document.getElementById("sortFilter").addEventListener("change", applyFilters);

document.getElementById("clearSearch").addEventListener("click", function () {
    document.getElementById("searchInput").value = "";
    document.getElementById("bookSearch").value = "";
    applyFilters();
});

document.getElementById("resetFilters").addEventListener("click", function () {
    document.getElementById("searchInput").value = "";
    document.getElementById("bookSearch").value = "";
    document.getElementById("categoryFilter").value = "All";
    document.getElementById("sortFilter").value = "default";
    applyFilters();
});

document.getElementById("surpriseBtn").addEventListener("click", surpriseMe);
document.getElementById("themeToggle").addEventListener("click", toggleTheme);

/* Category dropdown and category cards */
document.querySelectorAll(".category-option, .category-card").forEach(element => {
    element.addEventListener("click", function () {
        setCategory(this.dataset.category);
    });
});

/* Book registration */
document.getElementById("bookForm").addEventListener("submit", function (event) {
    event.preventDefault();

    if (!this.checkValidity()) {
        this.classList.add("was-validated");
        showToast("Form Incomplete", "Please fill in all required fields.");
        return;
    }

    const name = document.getElementById("bookName").value.trim();
    const author = document.getElementById("authorName").value.trim();

    showToast(
        "✓ Book Registered",
        `"${name}" by ${author} has been registered successfully.`
    );

    this.reset();
    this.classList.remove("was-validated");
});

/* Initialize */
bookStat.textContent = `${books.length}+`;
updateThemeIcon();
renderTrending();
renderBooks();
renderFavorites();
renderRecommendations();
